// ==UserScript==
// @name          Wykop.pl colored plus voters
// @namespace     http://userstyles.org
// @description	  Style attach colors to voters nicknames in the plus voters list
// @author        pczstyles
// @homepage      https://userstyles.org/styles/149619
// @include       http://wykop.pl/*
// @include       https://wykop.pl/*
// @include       http://*.wykop.pl/*
// @include       https://*.wykop.pl/*
// @run-at        document-start
// @version       0.20171014161252
// ==/UserScript==
(function() {var css = [
	"@namespace url(http://www.w3.org/1999/xhtml);",
	".votersContainer .voters-list .color-0 { color: #339933 !important; }",
	"    .votersContainer .voters-list .color-1 { color: #ff5917 !important; }",
	"    .votersContainer .voters-list .color-2 { color: #BB0000 !important; }",
	"    .votersContainer .voters-list .color-3 { color: #ff0000 !important; }",
	"  	.votersContainer .voters-list .color-4 { color: #999999 !important; }"
].join("\n");
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
