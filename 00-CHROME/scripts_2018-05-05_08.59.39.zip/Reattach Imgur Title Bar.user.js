// ==UserScript==
// @name          Reattach Imgur Title Bar
// @namespace     http://userstyles.org
// @description	  Removes the fixed title bar that obstructs view from the post.
// @author        phinet
// @homepage      https://userstyles.org/styles/119055
// @run-at        document-start
// @include       http://imgur.com/*
// @include       https://imgur.com/*
// @include       http://*.imgur.com/*
// @include       https://*.imgur.com/*
// @version       0.20150922173300
// ==/UserScript==
(function() {var css = "";
css += [
		"/* Reattach Imgur Title Bar */",
		"/* Author: Marcus Minhorst */",
		"",
		"@namespace html url(\'http://www.w3.org/1999/xhtml\');"
	].join("\n");
if (false || (document.domain == "imgur.com" || document.domain.substring(document.domain.indexOf(".imgur.com") + 1) == "imgur.com"))
	css += [
		".post-container {",
		"        padding-top:",
		"            0px !important;",
		"    }",
		"    ",
		"    .fixed-share-container {",
		"        margin-top:",
		"            40px !important;",
		"    }",
		"    ",
		"    .post-header {",
		"        border-radius:",
		"            5px 5px 0px 0px !important;",
		"        position:",
		"            relative !important;",
		"    }"
	].join("\n");
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
