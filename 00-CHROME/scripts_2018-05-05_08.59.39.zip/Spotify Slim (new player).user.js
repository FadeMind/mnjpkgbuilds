// ==UserScript==
// @name          Spotify Slim (new player)
// @namespace     http://userstyles.org
// @description	  Makes the new Sotify player less bulky.
// @author        Danode
// @homepage      https://userstyles.org/styles/141950
// @include       http://open.spotify.com/*
// @include       https://open.spotify.com/*
// @include       http://*.open.spotify.com/*
// @include       https://*.open.spotify.com/*
// @run-at        document-start
// @version       0.20170429183421
// ==/UserScript==
(function() {var css = [
	"@namespace url(http://www.w3.org/1999/xhtml);",
	".tracklist-row { height: 3em; }",
	"  .tracklist-row .tracklist-col.name .track-name-wrapper .artists-album { display: inline; padding-left: 10px; }",
	"  .now-playing-bar__left { width: 20%; }",
	"  .now-playing-bar__center { width: 60%; max-width: unset; }",
	"  .now-playing-bar__right { width: 20%; }",
	"  .play-pause { text-align:center; }",
	"  .position.top-align svg { margin-right: 8px; }",
	"  .inputBox-input { font-size: 30px; }",
	"  .media-object .cover-art.rounded .cover-art-image { border-radius: 0; }",
	"  .tracklist-row.tracklist-row--oneline, .tracklist-row.tracklist-row--oneline .tracklist-col { height: 3em; }",
	"  .search-history li a h1 { font-size: 30px; }"
].join("\n");
if (typeof GM_addStyle != "undefined") {
	GM_addStyle(css);
} else if (typeof PRO_addStyle != "undefined") {
	PRO_addStyle(css);
} else if (typeof addStyle != "undefined") {
	addStyle(css);
} else {
	var node = document.createElement("style");
	node.type = "text/css";
	node.appendChild(document.createTextNode(css));
	var heads = document.getElementsByTagName("head");
	if (heads.length > 0) {
		heads[0].appendChild(node);
	} else {
		// no head yet, stick it whereever
		document.documentElement.appendChild(node);
	}
}
})();
